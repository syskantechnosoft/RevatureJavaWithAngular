import { Injectable } from '@angular/core';
import { Employee } from './employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  constructor() { }

  getEmployees() : Employee[]{
    return [
      {"id" : 12 , "name" : "poko", "age" : 22 },
      {"id" : 13 , "name" : "Joseph", "age" : 25 },
      {"id" : 14 , "name" : "Alex", "age" : 35 }
    ];
  }
}
