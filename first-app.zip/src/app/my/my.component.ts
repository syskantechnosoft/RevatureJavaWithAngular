import { Component, OnInit } from '@angular/core';
import { Customer } from './customer';

@Component({
  selector: 'app-my',
  templateUrl: './my.component.html',
  styleUrls: ['./my.component.css']
})
export class MyComponent implements OnInit {

  image = "https://assets.winni.in/c_limit,dpr_1,fl_progressive,q_80,w_600/35184_everlasting-paradise.jpeg";

  customers : Customer[] = [
    {id : 234 , name: 'John'},
    {id : 235 , name: 'Adam'},
    {id : 236 , name: 'Nick'}
  ];
  lastLoggedInTime:Date;

  name :string = "Test String";

  constructor() {
    this.lastLoggedInTime = new Date(2018, 5, 25);
   }

   click():void{
    console.log("It's clicked!!");
  }
  ngOnInit(): void {

    this.customers  = [
      {id : 234 , name: 'John'},
      {id : 235 , name: 'Adam'},
      {id : 236 , name: 'Nick'}
    ];

    // this.lastLoggedInTime = new Date(2018, 5, 25);
  }

}
