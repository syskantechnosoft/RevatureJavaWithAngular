import { Component } from "@angular/core";
import { Employee } from "./employee";
import { EmployeeService } from "./employee.service";

@Component({
    selector: 'app-employee-names',
    template: `<div>
    <h2> Employee Names</h2>
    <ul *ngFor = "let emp of employees">
      <li> {{ emp.name }} </li>
    </ul>
  </div>`,
    styles: []
})
export class EmployeeNamesComponent {
    // public employees = [
    //     { "id": 12, "name": "Chris", "age": 22 },
    //     { "id": 13, "name": "Joseph", "age": 25 },
    //     { "id": 14, "name": "Alex", "age": 35 }
    // ];
    public employees: Employee[];
    constructor(private _employeeService : EmployeeService){
            this.employees = _employeeService.getEmployees();
  }
}