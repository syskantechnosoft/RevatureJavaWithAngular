import { Component } from "@angular/core";

@Component({
    selector: 'app-employee-List',
    template:`<div>
    <h2> Employee Details</h2>
    <ul *ngFor = "let emp of employees">
      <li>{{ emp.id }} - {{ emp.name }} - {{ emp.age }}</li>
    </ul>
  </div>`,
    styles: []
  })
  export class EmployeeDetailsComponent {
    public employees = [
      {"id" : 12 , "name" : "Chris", "age" : 22 },
      {"id" : 13 , "name" : "Joseph", "age" : 25 },
      {"id" : 14 , "name" : "Alex", "age" : 35 }
    ];
  }