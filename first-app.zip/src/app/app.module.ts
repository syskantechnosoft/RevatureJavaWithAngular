import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {FormsModule} from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MyComponent } from './my/my.component';

import { WordcountPipe} from './wordcount.pipe';
import { EmployeeNamesComponent } from './employeename.component';
import { EmployeeDetailsComponent } from './employeedetails.component';

@NgModule({
  declarations: [
    AppComponent,
    MyComponent,
    WordcountPipe,
    EmployeeNamesComponent,
    EmployeeDetailsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
