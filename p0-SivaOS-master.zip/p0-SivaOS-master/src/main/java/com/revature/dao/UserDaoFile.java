package com.revature.dao;

import java.util.List;

import com.revature.beans.User;

/**
 * Implementation of UserDAO that reads and writes to a file
 */
public class UserDaoFile implements UserDao {
	
	public static String fileLocation = "";

	public User addUser(User user) {
		// TODO Auto-generated method stub
		return null;
	}

	public User getUser(Integer userId) {
		// TODO Auto-generated method stub
		return null;
	}

	public User getUser(String username, String pass) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<User> getAllUsers() {
		// TODO Auto-generated method stub
		return null;
	}

	public User updateUser(User u) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean removeUser(User u) {
		// TODO Auto-generated method stub
		return false;
	}

}
