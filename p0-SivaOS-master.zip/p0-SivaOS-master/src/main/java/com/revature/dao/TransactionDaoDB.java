package com.revature.dao;

import java.util.List;

import com.revature.beans.Transaction;

public class TransactionDaoDB implements TransactionDao {

	public List<Transaction> getAllTransactions() {
		// TODO Auto-generated method stub
		return null;
	}

}
