package com.revature.dao;

import java.util.List;

import com.revature.beans.User;

/**
 * Implementation of UserDAO that reads/writes to a relational database
 */
public class UserDaoDB implements UserDao {

	public User addUser(User user) {
		// TODO Auto-generated method stub
		return null;
	}

	public User getUser(Integer userId) {
		// TODO Auto-generated method stub
		return null;
	}

	public User getUser(String username, String pass) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<User> getAllUsers() {
		// TODO Auto-generated method stub
		return null;
	}

	public User updateUser(User u) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean removeUser(User u) {
		// TODO Auto-generated method stub
		return false;
	}

}
