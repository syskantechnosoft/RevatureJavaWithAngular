package com.revature.tutorialservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TutorialserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
