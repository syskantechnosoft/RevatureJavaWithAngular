package com.revature.tutorialservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TutorialserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TutorialserviceApplication.class, args);
	}

}
