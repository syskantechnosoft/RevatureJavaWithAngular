package com.revature.tutorialservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.revature.tutorialservice.model.Student;
import com.revature.tutorialservice.service.StudentService;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:4200")
public class StudentController {

	@Autowired
	StudentService studentService;

	@GetMapping("/students")
	public List<Student> findAll() {
		// TODO Auto-generated method stub
		return studentService.findAll();
	}

	@GetMapping("/students/{id}")
	public Student findById(@PathVariable int id) {
		// TODO Auto-generated method stub
		return studentService.findById(id);
	}

	@PostMapping("/students")
	public void addStudent(@RequestBody Student student) {
		// TODO Auto-generated method stub
		studentService.addStudent(student);
	}
	@PutMapping("/students/{id}")
	public void updateStudent(@PathVariable int id, @RequestBody Student student) {
		// TODO Auto-generated method stub
		studentService.updateStudent(id, student);
	}

	@DeleteMapping("/students/{id}")
	public void deleteStudent(@PathVariable int id) {
		// TODO Auto-generated method stub
		studentService.deleteStudent(id);
	}

	@DeleteMapping("/students")
	public void deleteAll() {
		// TODO Auto-generated method stub
		studentService.deleteAll();
	}
}
