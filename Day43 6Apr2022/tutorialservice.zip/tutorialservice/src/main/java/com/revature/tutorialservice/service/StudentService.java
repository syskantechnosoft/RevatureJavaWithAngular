package com.revature.tutorialservice.service;

import java.util.List;

import com.revature.tutorialservice.model.Student;

public interface StudentService {

	public List<Student> findAll();

	public Student findById(int id);

	public void addStudent(Student student);

	public void updateStudent(int id, Student student);

	public void deleteStudent(int id);

	public void deleteAll();
}
