package com.revature.tutorialservice.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.revature.tutorialservice.model.Student;

public interface StudentRepository extends JpaRepository<Student, Integer> {

}
