import { TestBed } from '@angular/core/testing';

import { StudentService1 } from './student1.service';

describe('StudentService', () => {
  let service: StudentService1;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(StudentService1);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
