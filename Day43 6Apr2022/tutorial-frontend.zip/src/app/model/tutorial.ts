export class Tutorial {
    id?: number;
    title?: string;
    description?: string;
    published?: boolean;

}
