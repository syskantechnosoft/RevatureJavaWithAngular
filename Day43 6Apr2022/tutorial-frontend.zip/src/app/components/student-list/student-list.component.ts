import { Component, OnInit } from '@angular/core';
import { Student } from 'src/app/model/student';
import { StudentService } from 'src/app/student.service';

@Component({
  selector: 'student-list',
  templateUrl: './student-list.component.html',
  styleUrls: ['./student-list.component.css']
})
export class StudentListComponent implements OnInit {
  students: Student[] = [];
  /*------------------------------------------
 --------------------------------------------
 Created constructor
 --------------------------------------------
 --------------------------------------------*/
  constructor(public studentService: StudentService) { }

  /**
   * Write code on Method
   *
   * @return response()
   */
  ngOnInit(): void {
    this.studentService.getAll().subscribe((data: Student[]) => {
      this.students = data;
      console.log(this.students);
    })
  }

  /**
   * Write code on Method
   *
   * @return response()
   */
  deleteStudent(id: number) {
    this.studentService.delete(id).subscribe(res => {
      this.students = this.students.filter(item => item.id !== id);
      console.log('Student deleted successfully!');
    })
  }

}
