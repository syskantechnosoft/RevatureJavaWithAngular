package com.revature.p1backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class P1finalBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
