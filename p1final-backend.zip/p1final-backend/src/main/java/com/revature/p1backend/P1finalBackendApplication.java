package com.revature.p1backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class P1finalBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(P1finalBackendApplication.class, args);
	}

}
