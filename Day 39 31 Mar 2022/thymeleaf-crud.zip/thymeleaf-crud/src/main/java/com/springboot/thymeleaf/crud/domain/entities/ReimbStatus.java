package com.springboot.thymeleaf.crud.domain.entities;

public enum ReimbStatus {
	PENDING, APPROVED, DENIED

}
