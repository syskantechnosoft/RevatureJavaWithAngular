package com.springboot.thymeleaf.crud.domain.entities;

public enum ReimbType {
	FOOD, TRAVEL, LODGING, OTHER
}
