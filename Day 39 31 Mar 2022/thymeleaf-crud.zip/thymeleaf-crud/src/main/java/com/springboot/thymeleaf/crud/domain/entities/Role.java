package com.springboot.thymeleaf.crud.domain.entities;

public enum Role {
    GUEST,
    USER,
    ADMIN
}
